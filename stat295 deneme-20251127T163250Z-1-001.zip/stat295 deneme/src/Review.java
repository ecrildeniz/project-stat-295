public class Review {
    private int rating;
    private String comment;
    private String customer;

    public Review(int rating, String comment, String customer) {
        this.rating = rating;
        this.comment = comment;
        this.customer = customer;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public String getCustomer() {
        return customer;
    }
}