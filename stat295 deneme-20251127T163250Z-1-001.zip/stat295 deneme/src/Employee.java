public class Employee extends User {
    private int id;
    private String name;
    private String position;

    public Employee(int id, String name, String position, String username, String password) {
        super(username, password);
        this.id = id;
        this.name = name;
        this.position = position;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    @Override
    public String getUserRole() {
        return "Employee";
    }
}