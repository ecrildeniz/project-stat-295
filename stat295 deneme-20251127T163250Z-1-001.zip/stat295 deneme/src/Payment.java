import java.util.Date;

public class Payment {
    private double amount;
    private Date date;
    private String status;
    private String method;

    public Payment(double amount, Date date, String status, String method) {
        this.amount = amount;
        this.date = date;
        this.status = status;
        this.method = method;
    }

    public double getAmount() {
        return amount;
    }

    public Date getDate() {
        return date;
    }

    public String getStatus() {
        return status;
    }

    public String getMethod() {
        return method;
    }

    public boolean processPayment() {
        return amount > 0;
    }
}