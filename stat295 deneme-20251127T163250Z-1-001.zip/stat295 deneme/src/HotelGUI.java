import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;
import java.util.List;

public class HotelGUI {
    private Hotel hotel;
    private JTextArea outputArea;
    private JFrame frame;
    private Employee defaultEmployee;

    public HotelGUI(Hotel hotel) {
        this.hotel = hotel;
        this.defaultEmployee = new Employee(1, "Fatma Yılmaz", "Receptionist", "fatma", "5678");
    }

    public void createAndShowGUI() {
        frame = new JFrame("Hotel Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(750, 500);
        frame.setLocationRelativeTo(null);
        setupMainInterface();
    }

    private void setupMainInterface() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JPanel centerPanel = new JPanel(new BorderLayout());

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(outputArea);

        JLabel welcomeLabel = new JLabel("Logged in as: EMPLOYEE", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        JButton viewAllBookingsBtn = new JButton("📋 View All Bookings");
        JButton addRoomBtn = new JButton("➕ Add New Room");
        JButton viewGuestDetailsBtn = new JButton("👤 View Guest Details");

        viewAllBookingsBtn.addActionListener(this::handleViewAllBookings);
        addRoomBtn.addActionListener(this::handleAddRoom);
        viewGuestDetailsBtn.addActionListener(this::handleViewGuestDetails);

        topPanel.add(welcomeLabel);
        topPanel.add(viewAllBookingsBtn);
        topPanel.add(addRoomBtn);
        topPanel.add(viewGuestDetailsBtn);

        centerPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(mainPanel);
        frame.revalidate();
        frame.repaint();
    }

    private void handleViewAllBookings(ActionEvent e) {
        StringBuilder sb = new StringBuilder("📋 All Bookings:\n\n");
        for (Booking b : hotel.getBookings()) {
            sb.append("Room ").append(b.getRoom().getNumber())
              .append(" | Customer: ").append(b.getCustomer().getName())
              .append(" | From: ").append(b.getStartDate())
              .append(" to ").append(b.getEndDate()).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    private void handleAddRoom(ActionEvent e) {
        int roomNumber = hotel.getRooms().size() + 100;
        Room room = new Room(roomNumber, "Standard", 120);
        hotel.addRoom(room);
        outputArea.setText("✅ Room Added: " + room.toString());
    }

    private void handleViewGuestDetails(ActionEvent e) {
        StringBuilder sb = new StringBuilder("👥 Guest Details:\n\n");
        for (Booking b : hotel.getBookings()) {
            Customer c = b.getCustomer();
            sb.append("Name: ").append(c.getName()).append("\n")
              .append("Email: ").append(c.getEmail()).append("\n")
              .append("Room: ").append(b.getRoom().getNumber()).append("\n")
              .append("--------------------------\n");
        }
        outputArea.setText(sb.toString());
    }
}